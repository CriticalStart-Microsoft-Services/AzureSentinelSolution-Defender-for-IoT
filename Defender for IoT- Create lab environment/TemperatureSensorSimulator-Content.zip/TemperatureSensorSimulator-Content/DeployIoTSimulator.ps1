﻿
param( [Parameter(Mandatory = $true)] [int]$DeviceCount)

if(((Get-Location).Path -split "\\")[-1] -ne 'TemperatureSensorSimulator-Content')
{
    Write-Host "Please launch script from TemperatureSensorSimulator-Content folder!!!!" -ForegroundColor Red
    exit
}


try{

    "Starting Docker service" | Format-Color @{'.' = "Green"}
    Start-Service Docker
    Start-Sleep -Seconds 5
}
 catch {
             Write-Host "An error occurred starting docker"
            Write-Host $_Exception
            exit
            }

#Check if transparent network is created
try{

    "Checking Transparent network.........."| Format-Color @{'.' = "Green"};
        (docker network inspect DockerNet) | Out-Null
    "`t`tDockerNet Transparent network Is Present"| Format-Color @{'.' = "Yellow "};

        }

    catch {
        try {
            "Creating Transparent network.........."| Format-Color @{'.' = "Yellow"};
            docker network create -d transparent --subnet=192.168.1.0/24 --gateway=192.168.1.1 DockerNet | Out-Null
        }
        catch{ Write-Host "An error occurred creating docker transparent network!!" -ForegroundColor Red
            Write-Host $_Exception
            exit}
        }

#region...Format color for output text
function Format-Color([hashtable] $Colors = @{}, [switch] $SimpleMatch) {
	$lines = ($input | Out-String) -replace "`r", "" -split "`n"
	foreach($line in $lines) {
		$color = ''
		foreach($pattern in $Colors.Keys){
			if(!$SimpleMatch -and $line -match $pattern) { $color = $Colors[$pattern] }
			elseif ($SimpleMatch -and $line -like $pattern) { $color = $Colors[$pattern] }
		}
		if($color) {
			Write-Host -ForegroundColor $color $line
		} else {
			Write-Host $line
		}
	}
}
#endregion



# Login In
Connect-AzAccount | Out-Null 


# Get Subscription details
"Subscription Select:" | Format-Color @{'.' = "Green"}
$Context = Get-AzSubscription | Out-GridView -PassThru -Title "Please Select Subscription:" | Set-AzContext | Format-Color @{'.' = "Green"}

# identify the IoT Hub
$IoTHub = Get-AzResource -ResourceType "Microsoft.Devices/IotHubs" | Out-GridView -PassThru -Title "Please Select IoT-Hub Resource:"

"Azure IoT Resource Name:" | Format-Color @{'.' = "Green"}
$IoTHub | Format-Color @{'.' = "Green"}

#region... Register IoT Devices 


function Register-Device 
{

 #Delete existing IoT Device names
            $IOTNames= (Get-AzIotHubDevice -ResourceGroupName $IoTHub.ResourceGroupName $IoTHub.Name).id | Where-Object{$_ -like "IoT-Device*"}

            foreach($name in $IOTNames)
            {
            
                Remove-AzIotHubDevice -IotHubName $IoTHub.Name -ResourceGroupName $IoTHub.ResourceGroupName -DeviceId $name
            
            }


    "Deleting old instances in docker.........."| Format-Color @{'.' = "White"};
        if((docker ps).count -gt 1) 
        {docker stop $(docker ps -a -q)  | Out-Null -ErrorAction SilentlyContinue
         docker rm $(docker ps -a -q)| Out-Null -ErrorAction SilentlyContinue
        }
        

 

    "`tStarting Azure IoT Device Registration:"| Format-Color @{'.' = "Magenta"}

    $DeviceConnectionString = $null;
    for ($i = 1; $i -le $DeviceCount; $i++)
        { 
         "---------------------------------------------IoT-Device$i-------------------------------------------------"| Format-Color @{'.' = "Magenta"}
        

                "`t`tCreating NEW Azure IoT Device registration: IoT-Device$i"| Format-Color @{'.' = "Magenta";'IoT-Device\d' = "Yellow"};
                Add-AzIotHubDevice -ResourceGroupName $IoTHub.ResourceGroupName -IotHubName $IoTHub.Name -DeviceId "IoT-Device$i" -AuthMethod "shared_private_key"  -Force | Out-Null
                $DeviceConnectionString = (Get-AzIotHubDeviceConnectionString -ResourceGroupName $IoTHub.ResourceGroupName $IoTHub.Name -DeviceId "IoT-Device$i").ConnectionString
           

             "`t`tDeploying TemperatureSensorSimulator docker container: IoT-Device$i"| Format-Color @{'.' = "Cyan"};
            (Get-Content -Path ".\TemperatureSensorSimulator\Master.txt" -Raw) -replace "IoTHubDeviceConnectionString", $DeviceConnectionString -replace "IoTDeviceName", "IoT-Device$i" |
            Set-Content ".\TemperatureSensorSimulator\Program.cs"

            try{
            docker build -t app '.\TemperatureSensorSimulator\' | Out-Null

            docker run -d -it --network=DockerNet -P --name ("IoT-Device$i") app | Out-Null

             "`t`tDeployed TemperatureSensorSimulator docker container: IoT-Device$i"| Format-Color @{'.' = "Green"};
            }
            catch {
             Write-Host "An error occurred:"
            Write-Host $_Exception
            }

        }

         "`n`n`n$DeviceCount IoT Simulator devices deployed: "| Format-Color @{'.' = "Green"}
         foreach($d in (1..$DeviceCount)){
         "`t`t$(docker inspect --format='{{.Name}} - {{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' IoT-Device$d)" | Format-Color @{'.' = "Green"}
         }

         "----------------------------------------------------------------------------------------------"| Format-Color @{'.' = "Green"}

}
#endregion 


Register-Device

